Feedback Simple
A very simple, very light, CSS only Feedback tab.

Configure at admin/appearance/feedback-simple.

Enjoy!
